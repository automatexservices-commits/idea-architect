import { createClient } from "npm:@insforge/sdk";
import JSZip from "npm:jszip";

type DocKind = "prd" | "system_design" | "architecture";
type DownloadFormat = "md" | "pdf" | "zip";

type AuthUser = {
  id: string;
  email?: string;
  user_metadata?: Record<string, unknown>;
};

type ProjectRecord = {
  id: string;
  user_id: string;
  title: string;
  idea: string;
  description: string | null;
  stack_recommendation: Record<string, unknown>;
  generation_state: "idle" | "generating" | "ready" | "failed";
  current_stage: string;
  download_count: number;
  last_generated_at: string | null;
  created_at: string;
  updated_at: string;
};

type DocumentRecord = {
  id: string;
  project_id: string;
  user_id: string;
  document_type: DocKind;
  title: string;
  status: "pending" | "generating" | "ready" | "failed";
  current_version_id: string | null;
  latest_checksum: string | null;
  created_at: string;
  updated_at: string;
};

type DocumentVersionRecord = {
  id: string;
  document_id: string;
  version_number: number;
  content_markdown: string;
  structured_data: Record<string, unknown>;
  file_format: "md" | "pdf" | "json";
  file_name: string;
  checksum: string;
  ai_model: string | null;
  prompt_version: string;
  token_usage: Record<string, unknown>;
  created_at: string;
};

type BackendContext = {
  client: ReturnType<typeof createClient>;
  user: AuthUser;
  profile: {
    id: string;
    email: string;
    full_name: string | null;
    role: "free" | "pro";
  };
};

type UsageState = {
  role: "free" | "pro";
  limit: number;
  used: number;
  remaining: number;
  blocked: boolean;
};

type RazorpayPlan = "pro" | "enterprise" | "custom";
type RazorpayOrder = {
  id: string;
  amount: number;
  currency: string;
  receipt?: string;
  status?: string;
};

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Access-Control-Max-Age": "86400",
};

const AI_MODEL = "anthropic/claude-sonnet-4.5";
const PROMPT_VERSION = "v1";
const ROUTE_PREFIX = "/functions/backend";
const OPENAI_MODEL = "gpt-4o-mini";
const GEMINI_MODEL = "gemini-2.0-flash";
const OPENROUTER_MODEL = "openai/gpt-4o-mini";

function jsonResponse(status: number, payload: unknown) {
  return new Response(JSON.stringify(payload, null, 2), {
    status,
    headers: {
      ...CORS_HEADERS,
      "Content-Type": "application/json; charset=utf-8",
    },
  });
}

function textResponse(
  status: number,
  body: string,
  filename: string,
  contentType: string,
) {
  return new Response(body, {
    status,
    headers: {
      ...CORS_HEADERS,
      "Content-Type": contentType,
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}

function binaryResponse(
  status: number,
  bytes: Uint8Array,
  filename: string,
  contentType: string,
) {
  return new Response(bytes, {
    status,
    headers: {
      ...CORS_HEADERS,
      "Content-Type": contentType,
      "Content-Disposition": `attachment; filename="${filename}"`,
      "Cache-Control": "no-store",
    },
  });
}

function stripRoutePrefix(pathname: string) {
  if (pathname.startsWith(ROUTE_PREFIX)) {
    const trimmed = pathname.slice(ROUTE_PREFIX.length);
    return trimmed.length ? trimmed : "/";
  }
  return pathname || "/";
}

function normalizeRoute(pathname: string) {
  return stripRoutePrefix(pathname).replace(/\/+$/, "") || "/";
}

function isUuid(value: string | undefined) {
  return Boolean(value && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value));
}

function isRazorpayPlan(value: string): value is RazorpayPlan {
  return value === "pro" || value === "enterprise" || value === "custom";
}

function planConfig(plan: RazorpayPlan) {
  const base = {
    currency: "INR",
    name: "PLANNR",
    image: undefined as string | undefined,
  };

  if (plan === "pro") {
    return {
      ...base,
      amountInInr: Number(Deno.env.get("RAZORPAY_PRO_AMOUNT_INR") ?? "49"),
      description: "PLANNR Pro monthly plan",
    };
  }

  if (plan === "enterprise") {
    return {
      ...base,
      amountInInr: Number(Deno.env.get("RAZORPAY_ENTERPRISE_AMOUNT_INR") ?? "150"),
      description: "PLANNR Enterprise monthly plan",
    };
  }

  return {
    ...base,
    amountInInr: Number(Deno.env.get("RAZORPAY_CUSTOM_AMOUNT_INR") ?? "0"),
    description: "PLANNR Custom plan",
  };
}

async function createRazorpayOrder(plan: RazorpayPlan) {
  const keyId = Deno.env.get("RAZORPAY_KEY_ID");
  const keySecret = Deno.env.get("RAZORPAY_KEY_SECRET");

  if (!keyId || !keySecret) {
    throw new Error("RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET must be configured.");
  }

  const config = planConfig(plan);
  if (!config.amountInInr || config.amountInInr <= 0) {
    throw new Error(`Missing configured amount for ${plan} plan.`);
  }

  const amount = Math.round(config.amountInInr * 100);
  const receipt = `plannr-${plan}-${Date.now()}`;
  const auth = btoa(`${keyId}:${keySecret}`);

  const response = await fetch("https://api.razorpay.com/v1/orders", {
    method: "POST",
    headers: {
      Authorization: `Basic ${auth}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      amount,
      currency: config.currency,
      receipt,
      notes: {
        plan,
        product: "PLANNR",
      },
    }),
  });

  const payload = await response.json() as RazorpayOrder & { error?: { description?: string; reason?: string; message?: string } };
  if (!response.ok) {
    const message = payload?.error?.description || payload?.error?.message || `Razorpay order creation failed (${response.status})`;
    throw new Error(message);
  }

  return {
    orderId: payload.id,
    amount,
    currency: config.currency,
    name: config.name,
    description: config.description,
    image: config.image,
    keyId,
    receipt,
  };
}

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80) || "document";
}

function titleForKind(kind: DocKind) {
  switch (kind) {
    case "prd":
      return "Product Requirements Document";
    case "system_design":
      return "System Design";
    case "architecture":
      return "Architecture";
  }
}

function filenameForKind(kind: DocKind, title: string, format: DownloadFormat) {
  const base = `${slugify(title)}-${kind}`;
  if (format === "pdf") return `${base}.pdf`;
  if (format === "zip") return `${base}.zip`;
  return `${base}.md`;
}

async function sha256(text: string) {
  const bytes = new TextEncoder().encode(text);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

function flattenContent(content: unknown): string {
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    return content
      .map((part) => (typeof part === "string" ? part : part && typeof part === "object" && "text" in part ? String((part as { text?: unknown }).text ?? "") : ""))
      .join("");
  }
  if (content && typeof content === "object" && "text" in content) {
    return String((content as { text?: unknown }).text ?? "");
  }
  return "";
}

function extractAiText(result: unknown) {
  const candidate =
    (result as { choices?: Array<{ message?: { content?: unknown } }> })?.choices?.[0]?.message?.content ??
    (result as { data?: Array<{ message?: { content?: unknown } }> })?.data?.[0]?.message?.content ??
    (result as { output_text?: unknown })?.output_text ??
    (result as { text?: unknown })?.text ??
    "";

  return flattenContent(candidate);
}

function extractJson(text: string) {
  const trimmed = text.trim();
  if (!trimmed) return null;

  const fenceMatch = trimmed.match(/```json\s*([\s\S]*?)```/i);
  const raw = fenceMatch?.[1]?.trim() ?? trimmed;

  const firstBrace = raw.indexOf("{");
  const lastBrace = raw.lastIndexOf("}");
  const slice = firstBrace >= 0 && lastBrace > firstBrace ? raw.slice(firstBrace, lastBrace + 1) : raw;

  try {
    return JSON.parse(slice) as Record<string, unknown>;
  } catch {
    return null;
  }
}

function providerKeys() {
  return [
    Deno.env.get("OPENAI_API_KEY"),
    Deno.env.get("GEMINI_API_KEY"),
  ].filter(Boolean) as string[];
}

function openRouterKeys() {
  return [
    Deno.env.get("OPENROUTER_API_KEY"),
    Deno.env.get("OPENROUTER_ANOTHER_API_KEY"),
    Deno.env.get("OPENROUTER_API_KEY_2"),
    Deno.env.get("OPENROUTER_API_KEY_3"),
  ].filter(Boolean) as string[];
}

async function fetchJsonText(url: string, init: RequestInit) {
  const response = await fetch(url, init);
  const text = await response.text();
  if (!response.ok) {
    throw new Error(text || `Request failed (${response.status})`);
  }
  return text;
}

async function fetchJsonTextWithTimeout(url: string, init: RequestInit, timeoutMs: number) {
  if (timeoutMs <= 0) {
    return await fetchJsonText(url, init);
  }

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    return await fetchJsonText(url, {
      ...init,
      signal: controller.signal,
    });
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new Error(`Request timed out after ${timeoutMs}ms`);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

async function callOpenAIChat(system: string, prompt: string) {
  const apiKey = Deno.env.get("OPENAI_API_KEY");
  if (!apiKey) throw new Error("OPENAI_API_KEY not configured");
  console.log("[ai] OpenAI request start");
  const text = await fetchJsonTextWithTimeout("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: OPENAI_MODEL,
      messages: [
        { role: "system", content: system },
        { role: "user", content: prompt },
      ],
      temperature: 0.2,
      max_tokens: 2600,
      response_format: { type: "json_object" },
    }),
  }, 15000);
  console.log("[ai] OpenAI response received");
  return extractAiText(JSON.parse(text));
}

async function callGeminiChat(system: string, prompt: string) {
  const apiKey = Deno.env.get("GEMINI_API_KEY");
  if (!apiKey) throw new Error("GEMINI_API_KEY not configured");
  console.log("[ai] Gemini request start");
  const text = await fetchJsonTextWithTimeout(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent?key=${apiKey}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: system }] },
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.2, responseMimeType: "application/json", maxOutputTokens: 4096 },
    }),
  }, 15000);
  console.log("[ai] Gemini response received");
  return extractAiText(JSON.parse(text));
}

async function callOpenRouterChat(system: string, prompt: string, key: string) {
  console.log("[ai] OpenRouter request start");
  const text = await fetchJsonTextWithTimeout("https://openrouter.ai/api/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
      "HTTP-Referer": "http://localhost",
      "X-Title": "PLANNR",
    },
    body: JSON.stringify({
      model: OPENROUTER_MODEL,
      messages: [
        { role: "system", content: system },
        { role: "user", content: prompt },
      ],
      temperature: 0.2,
      max_tokens: 2600,
    }),
  }, 20000);
  console.log("[ai] OpenRouter response received");
  return extractAiText(JSON.parse(text));
}

async function callStructuredAi<T extends Record<string, unknown>>(system: string, prompt: string, fallbackTitle: string) {
  try {
    const openAiText = await callOpenAIChat(system, prompt);
    const openAiJson = extractJson(openAiText);
    if (openAiJson) return { text: openAiText, json: openAiJson };
  } catch (error) {
    console.warn(`[ai] OpenAI failed for ${fallbackTitle}`, error);
  }

  try {
    const geminiText = await callGeminiChat(system, prompt);
    const geminiJson = extractJson(geminiText);
    if (geminiJson) return { text: geminiText, json: geminiJson };
  } catch (error) {
    console.warn(`[ai] Gemini failed for ${fallbackTitle}`, error);
  }

  const keys = openRouterKeys();
  for (const key of keys) {
    try {
      const routerText = await callOpenRouterChat(system, prompt, key);
      const routerJson = extractJson(routerText);
      if (routerJson) return { text: routerText, json: routerJson };
    } catch (error) {
      console.warn(`[ai] OpenRouter fallback failed for ${fallbackTitle}`, error);
    }
  }

  throw new Error(`Failed to generate ${fallbackTitle}`);
}

function stringifyList(items: unknown) {
  if (!Array.isArray(items) || items.length === 0) return "- None provided";
  return items.map((item) => `- ${String(item)}`).join("\n");
}

function stringifyKeyValueList(items: unknown) {
  if (!Array.isArray(items) || items.length === 0) return "- None provided";
  return items
    .map((item) => {
      if (!item || typeof item !== "object") return `- ${String(item)}`;
      const obj = item as Record<string, unknown>;
      const name = obj.name ?? obj.title ?? "Item";
      const details =
        obj.responsibility ??
        obj.summary ??
        obj.description ??
        obj.value ??
        obj.detail ??
        obj.steps ??
        obj.items ??
        obj.pain_points ??
        obj.goals ??
        obj.acceptance_criteria ??
        obj.notes ??
        "";
      if (Array.isArray(details)) {
        return `- ${String(name)}\n  - ${details.map((v) => String(v)).join("\n  - ")}`;
      }
      return `- ${String(name)}${details ? `: ${String(details)}` : ""}`;
    })
    .join("\n");
}

function renderMarkdown(kind: DocKind, payload: Record<string, unknown>, project: ProjectRecord) {
  const heading = String(payload.title ?? titleForKind(kind));
  const summary = String(payload.summary ?? "");

  if (kind === "prd") {
    return [
      `# ${heading}`,
      "",
      "## Executive Summary",
      summary || "No summary provided.",
      "",
      "## Product Vision",
      String(payload.product_vision ?? "Not provided."),
      "",
      "## Problem Statement",
      String(payload.problem_statement ?? "Not provided."),
      "",
      "## Target Users",
      stringifyList(payload.target_users),
      "",
      "## Personas",
      stringifyKeyValueList(payload.personas),
      "",
      "## Goals",
      stringifyList(payload.goals),
      "",
      "## Non-Goals",
      stringifyList(payload.non_goals),
      "",
      "## User Journeys",
      stringifyKeyValueList(payload.user_journeys ?? payload.core_flows),
      "",
      "## Feature Requirements",
      stringifyKeyValueList(payload.feature_requirements),
      "",
      "## Functional Requirements",
      stringifyList(payload.functional_requirements),
      "",
      "## Edge Cases",
      stringifyList(payload.edge_cases),
      "",
      "## Non-Functional Requirements",
      stringifyList(payload.non_functional_requirements),
      "",
      "## KPIs",
      stringifyList(payload.kpis ?? payload.success_metrics),
      "",
      "## Risks",
      stringifyList(payload.risks),
      "",
      "## Open Questions",
      stringifyList(payload.open_questions),
      "",
      "## Project Context",
      `- Title: ${project.title}`,
      `- Idea: ${project.idea}`,
    ].join("\n");
  }

  if (kind === "system_design") {
    return [
      `# ${heading}`,
      "",
      "## Summary",
      summary || "No summary provided.",
      "",
      "## Architecture Overview",
      String(payload.architecture_overview ?? "Not provided."),
      "",
      "## Components",
      stringifyKeyValueList(payload.components),
      "",
      "## Request Flow",
      stringifyList(payload.request_flow ?? payload.data_flow),
      "",
      "## Data Model",
      stringifyList(payload.data_model),
      "",
      "## API Contracts",
      stringifyList(payload.api_contracts),
      "",
      "## Async Jobs",
      stringifyList(payload.async_jobs),
      "",
      "## Security and Auth",
      stringifyList(payload.security_and_auth ?? payload.security),
      "",
      "## Scalability",
      stringifyList(payload.scalability),
      "",
      "## Observability",
      stringifyList(payload.observability),
      "",
      "## Failure Modes",
      stringifyList(payload.failure_modes),
      "",
      "## Cost Optimizations",
      stringifyList(payload.cost_optimizations),
      "",
      "## Project Context",
      `- Title: ${project.title}`,
      `- Idea: ${project.idea}`,
    ].join("\n");
  }

  return [
    `# ${heading}`,
    "",
    "## Summary",
    summary || "No summary provided.",
    "",
    "## Module Boundaries",
    stringifyList(payload.module_boundaries),
    "",
    "## Directory Structure",
    stringifyList(payload.directory_structure),
    "",
    "## Database Schema Notes",
    stringifyList(payload.database_schema_notes),
    "",
    "## Service Contracts",
    stringifyList(payload.service_contracts),
    "",
    "## Deployment Notes",
    stringifyList(payload.deployment_notes),
    "",
    "## Operational Workflows",
    stringifyList(payload.operational_workflows),
    "",
    "## Security Considerations",
    stringifyList(payload.security_considerations),
    "",
    "## Cost Controls",
    stringifyList(payload.cost_controls),
    "",
    "## Migration Notes",
    stringifyList(payload.migration_notes),
    "",
    "## Risks",
    stringifyList(payload.risks),
    "",
    "## Project Context",
    `- Title: ${project.title}`,
    `- Idea: ${project.idea}`,
  ].join("\n");
}

function buildPrompt(kind: DocKind, project: ProjectRecord, existingDocs: Array<{ document_type: DocKind; title: string; summary?: string }>) {
  const sharedContext = [
    `Project title: ${project.title}`,
    `Project idea: ${project.idea}`,
    project.description ? `Additional context: ${project.description}` : null,
    project.stack_recommendation && Object.keys(project.stack_recommendation).length
      ? `Existing stack recommendation: ${JSON.stringify(project.stack_recommendation)}`
      : null,
    existingDocs.length ? `Available documents: ${existingDocs.map((doc) => `${doc.document_type} (${doc.title})`).join(", ")}` : null,
  ]
    .filter(Boolean)
    .join("\n");

  if (kind === "prd") {
    return `
You are generating a production-grade PRD for an AI SaaS product that turns user ideas into PRD, system design, and architecture docs.
Use a formal enterprise template and write enough detail to feel like a real product spec.

Return valid JSON only. No markdown fences. No prose outside JSON.

Schema:
{
  "title": string,
  "summary": string,
  "product_vision": string,
  "problem_statement": string,
  "goals": string[],
  "non_goals": string[],
  "target_users": string[],
  "personas": [{ "name": string, "goals": string[], "pain_points": string[] }],
  "user_journeys": [{ "name": string, "steps": string[] }],
  "feature_requirements": [{ "feature": string, "description": string, "acceptance_criteria": string[] }],
  "functional_requirements": string[],
  "edge_cases": string[],
  "non_functional_requirements": string[],
  "kpis": string[],
  "open_questions": string[],
  "risks": string[]
}

Rules:
- Write a detailed PRD with clear sections and specific business language.
- Include flows, edge cases, success metrics, and risk notes.
- Prefer concrete and testable requirements over generic statements.
- Make it detailed enough to guide design and implementation.

Context:
${sharedContext}
`.trim();
  }

  if (kind === "system_design") {
    return `
You are generating a production-grade system design document for an AI SaaS product.
Use a structured template that reads like a real architecture review artifact.

Return valid JSON only. No markdown fences. No prose outside JSON.

Schema:
{
  "title": string,
  "summary": string,
  "architecture_overview": string,
  "components": [{ "name": string, "responsibility": string, "notes": string[] }],
  "request_flow": string[],
  "data_model": string[],
  "api_contracts": string[],
  "async_jobs": string[],
  "security_and_auth": string[],
  "scalability": string[],
  "observability": string[],
  "failure_modes": string[],
  "cost_optimizations": string[]
}

Rules:
- Focus on backend architecture, runtime behavior, and operational reliability.
- Include caching, rate limits, retries, queues, and persistence where relevant.
- Explain how the system scales and how failures are handled.
- Keep it implementation-ready and detailed.

Context:
${sharedContext}
`.trim();
  }

  return `
You are generating a production-grade software architecture document for an AI SaaS product.
Use a high-detail implementation template with module boundaries, deployment, and operational concerns.

Return valid JSON only. No markdown fences. No prose outside JSON.

Schema:
{
  "title": string,
  "summary": string,
  "module_boundaries": string[],
  "directory_structure": string[],
  "database_schema_notes": string[],
  "service_contracts": string[],
  "deployment_notes": string[],
  "operational_workflows": string[],
  "security_considerations": string[],
  "cost_controls": string[],
  "migration_notes": string[],
  "risks": string[]
}

Rules:
- Make the architecture implementation-ready and detailed.
- Include deployment, data ownership, migrations, and cost control choices.
- Keep it practical for a small team building and scaling.
- Describe concrete modules, boundaries, and failure handling.

Context:
${sharedContext}
`.trim();
  }

function buildQuestionsPrompt(idea: string, specs: string) {
  return `
Return valid JSON only.

Schema:
{
  "projectName": string,
  "questions": [{ "id": string, "question": string, "options": string[] }]
}

Rules:
- Create 5 to 7 short clarifying questions.
- Keep options practical and distinct.
- Make the project name short, product-like, and based on the idea.

Idea:
${idea}

Specs:
${specs || "None"}
`.trim();
}

function buildStackPrompt(idea: string, answers: Record<string, string>) {
  return `
Return valid JSON only.

Schema:
{
  "frontend": string,
  "backend": string,
  "database": string,
  "auth": string,
  "hosting": string,
  "rationale": string
}

Rules:
- Be practical and modern.
- Optimize for speed and scalability.
- Mention why the stack fits the idea.

Idea:
${idea}

Answers:
${JSON.stringify(answers, null, 2)}
`.trim();
}

async function callQuestionsAi(idea: string, specs: string) {
  const system = "You generate concise clarifying questions for product planning.";
  const { json } = await callStructuredAi(system, buildQuestionsPrompt(idea, specs), "questions");
  return {
    projectName: String(json.projectName ?? "Untitled Project"),
    questions: Array.isArray(json.questions) ? json.questions : [],
  };
}

async function callStackAi(idea: string, answers: Record<string, string>) {
  const system = "You recommend a practical production stack.";
  const { json } = await callStructuredAi(system, buildStackPrompt(idea, answers), "stack");
  return {
    frontend: String(json.frontend ?? "React"),
    backend: String(json.backend ?? "Node.js"),
    database: String(json.database ?? "PostgreSQL"),
    auth: String(json.auth ?? "Email/password and Google OAuth"),
    hosting: String(json.hosting ?? "Vercel"),
    rationale: String(json.rationale ?? "Recommended stack."),
  };
}

async function getInsForgeContext(req: Request): Promise<BackendContext | Response> {
  const baseUrl = Deno.env.get("INSFORGE_BASE_URL");
  const anonKey = Deno.env.get("ANON_KEY");
  if (!baseUrl || !anonKey) {
    return jsonResponse(500, {
      success: false,
      error: "Missing InsForge environment variables: INSFORGE_BASE_URL or ANON_KEY.",
    });
  }

  const authHeader = req.headers.get("Authorization") ?? req.headers.get("authorization");
  if (!authHeader?.startsWith("Bearer ")) {
    return jsonResponse(401, { success: false, error: "Unauthorized" });
  }

  const token = authHeader.slice("Bearer ".length).trim();
  if (!token) {
    return jsonResponse(401, { success: false, error: "Unauthorized" });
  }

  const client = createClient({
    baseUrl,
    anonKey,
    edgeFunctionToken: token,
  });

  const { data: currentUser, error } = await client.auth.getCurrentUser();
  if (error || !currentUser?.user?.id) {
    return jsonResponse(401, { success: false, error: "Unauthorized" });
  }

  const user = currentUser.user as AuthUser;
  const profile = await ensureUserProfile(client, user);
  return { client, user, profile };
}

async function ensureUserProfile(context: BackendContext["client"], user: AuthUser) {
  const email = user.email ?? "";
  const fullName = (user.user_metadata?.full_name ?? user.user_metadata?.name ?? null) as string | null;

  const { data: existing } = await context.database
    .from("users")
    .select("id,email,full_name,role")
    .eq("id", user.id)
    .maybeSingle();

  if (existing) {
    return existing as BackendContext["profile"];
  }

  const { data: inserted, error } = await context.database
    .from("users")
    .insert([{ id: user.id, email, full_name: fullName, role: "free" }])
    .select("id,email,full_name,role")
    .maybeSingle();

  if (error || !inserted) {
    throw new Error(error?.message ?? "Failed to create user profile");
  }

  return inserted as BackendContext["profile"];
}

async function getUsageState(context: BackendContext): Promise<UsageState> {
  const limit = context.profile.role === "pro" ? 100 : 3;
  const { data, error } = await context.client.database
    .from("usage_limits")
    .select("lifetime_generations")
    .eq("user_id", context.user.id)
    .maybeSingle();

  if (error) {
    throw new Error(error.message);
  }

  const used = Number((data as { lifetime_generations?: unknown } | null)?.lifetime_generations ?? 0);
  return {
    role: context.profile.role,
    limit,
    used,
    remaining: Math.max(limit - used, 0),
    blocked: context.profile.role !== "pro" && used >= 3,
  };
}

function limitExceededResponse(state: UsageState) {
  return jsonResponse(429, {
    success: false,
    code: "LIMIT_EXCEEDED",
    message: "Free limit reached",
    usage: state,
  });
}

async function assertGenerationAllowed(context: BackendContext) {
  const state = await getUsageState(context);
  if (state.blocked) {
    return { allowed: false as const, state };
  }
  return { allowed: true as const, state };
}

async function logEvent(
  client: BackendContext["client"],
  payload: {
    userId?: string;
    projectId?: string;
    route: string;
    method: string;
    level?: "info" | "warn" | "error";
    message: string;
    statusCode?: number;
    durationMs?: number;
    metadata?: Record<string, unknown>;
  },
) {
  try {
    await client.database.from("api_logs").insert([{
      user_id: payload.userId ?? null,
      project_id: payload.projectId ?? null,
      route: payload.route,
      method: payload.method,
      level: payload.level ?? "info",
      message: payload.message,
      status_code: payload.statusCode ?? null,
      duration_ms: payload.durationMs ?? null,
      metadata: payload.metadata ?? {},
    }]);
  } catch {
    // Logging should never break the API path.
  }
}

async function readJsonBody(req: Request) {
  const contentType = req.headers.get("content-type") ?? "";
  if (!contentType.includes("application/json")) return {};
  try {
    return await req.json();
  } catch {
    return {};
  }
}

async function getProjectOwnedByUser(client: BackendContext["client"], projectId: string, userId: string) {
  const { data, error } = await client.database
    .from("projects")
    .select("*")
    .eq("id", projectId)
    .eq("user_id", userId)
    .maybeSingle();

  if (error) throw new Error(error.message);
  if (!data) throw new Error("Project not found");
  return data as ProjectRecord;
}

async function getProjectDocuments(client: BackendContext["client"], projectId: string) {
  const { data, error } = await client.database
    .from("documents")
    .select("*")
    .eq("project_id", projectId)
    .order("created_at", { ascending: true });

  if (error) throw new Error(error.message);
  return (data ?? []) as DocumentRecord[];
}

async function getDocumentVersions(client: BackendContext["client"], documentId: string) {
  const { data, error } = await client.database
    .from("document_versions")
    .select("*")
    .eq("document_id", documentId)
    .order("version_number", { ascending: false });

  if (error) throw new Error(error.message);
  return (data ?? []) as DocumentVersionRecord[];
}

async function createProjectShell(client: BackendContext["client"], userId: string, title: string, idea: string, description?: string) {
  const { data: project, error: projectError } = await client.database
    .from("projects")
    .insert([{
      user_id: userId,
      title,
      idea,
      description: description ?? null,
      current_stage: "created",
      generation_state: "idle",
      stack_recommendation: {},
    }])
    .select("*")
    .maybeSingle();

  if (projectError || !project) {
    throw new Error(projectError?.message ?? "Failed to create project");
  }

  const docs = [
    { document_type: "prd" as const, title: `${title} PRD` },
    { document_type: "system_design" as const, title: `${title} System Design` },
    { document_type: "architecture" as const, title: `${title} Architecture` },
  ];

  const { error: docsError } = await client.database.from("documents").insert(
    docs.map((doc) => ({
      project_id: project.id,
      user_id: userId,
      document_type: doc.document_type,
      title: doc.title,
      status: "pending",
    })),
  );

  if (docsError) {
    throw new Error(docsError.message);
  }

  return project as ProjectRecord;
}

async function fetchExistingDocument(client: BackendContext["client"], projectId: string, kind: DocKind) {
  const { data, error } = await client.database
    .from("documents")
    .select("*")
    .eq("project_id", projectId)
    .eq("document_type", kind)
    .maybeSingle();

  if (error) throw new Error(error.message);
  return data as DocumentRecord | null;
}

async function updateDocumentStatus(
  client: BackendContext["client"],
  documentId: string,
  patch: Partial<Pick<DocumentRecord, "status" | "latest_checksum" | "current_version_id">>,
) {
  const { data, error } = await client.database
    .from("documents")
    .update(patch)
    .eq("id", documentId)
    .select("*")
    .maybeSingle();

  if (error || !data) {
    throw new Error(error?.message ?? "Failed to update document");
  }

  return data as DocumentRecord;
}

async function updateProject(
  client: BackendContext["client"],
  projectId: string,
  patch: Partial<ProjectRecord>,
) {
  const { data, error } = await client.database
    .from("projects")
    .update(patch)
    .eq("id", projectId)
    .select("*")
    .maybeSingle();

  if (error || !data) {
    throw new Error(error?.message ?? "Failed to update project");
  }

  return data as ProjectRecord;
}

async function createDocumentVersion(
  client: BackendContext["client"],
  document: DocumentRecord,
  contentMarkdown: string,
  structuredData: Record<string, unknown>,
  aiModel: string,
) {
  const existingVersions = await getDocumentVersions(client, document.id);
  const versionNumber = existingVersions.length ? existingVersions[0].version_number + 1 : 1;
  const checksum = await sha256(`${document.id}:${versionNumber}:${contentMarkdown}`);
  const fileName = filenameForKind(document.document_type, document.title, "md");

  const { data: inserted, error } = await client.database
    .from("document_versions")
    .insert([{
      document_id: document.id,
      version_number: versionNumber,
      content_markdown: contentMarkdown,
      structured_data: structuredData,
      file_format: "md",
      file_name: fileName,
      checksum,
      ai_model: aiModel,
      prompt_version: PROMPT_VERSION,
      token_usage: {},
    }])
    .select("*")
    .maybeSingle();

  if (error || !inserted) {
    throw new Error(error?.message ?? "Failed to save document version");
  }

  await updateDocumentStatus(client, document.id, {
    status: "ready",
    latest_checksum: checksum,
    current_version_id: inserted.id,
  });

  return inserted as DocumentVersionRecord;
}

async function callAiForDocument(
  client: BackendContext["client"],
  kind: DocKind,
  project: ProjectRecord,
  existingDocs: Array<{ document_type: DocKind; title: string; summary?: string }>,
) {
  const prompt = buildPrompt(kind, project, existingDocs);
  const system = "You are a senior product strategist and solutions architect. Return only JSON that exactly matches the requested schema.";
  const { json, text } = await callStructuredAi(system, prompt, titleForKind(kind));
  const structured = json ?? { title: titleForKind(kind), summary: text };
  const markdown = renderMarkdown(kind, structured, project);
  const usage = {};

  return { structured, markdown, usage };
}

function simplePdfEncode(text: string) {
  return text
    .replace(/\\/g, "\\\\")
    .replace(/\(/g, "\\(")
    .replace(/\)/g, "\\)");
}

function wrapText(text: string, maxChars = 92) {
  const lines: string[] = [];
  for (const paragraph of text.split(/\r?\n/)) {
    if (!paragraph.trim()) {
      lines.push("");
      continue;
    }

    const words = paragraph.split(/\s+/);
    let current = "";
    for (const word of words) {
      const next = current ? `${current} ${word}` : word;
      if (next.length > maxChars) {
        if (current) lines.push(current);
        current = word;
      } else {
        current = next;
      }
    }
    if (current) lines.push(current);
  }
  return lines;
}

function buildPdfBytes(title: string, markdown: string) {
  const lines = wrapText(`# ${title}\n\n${markdown}`, 92);
  const linesPerPage = 48;
  const pages: string[][] = [];
  for (let i = 0; i < lines.length; i += linesPerPage) {
    pages.push(lines.slice(i, i + linesPerPage));
  }
  if (!pages.length) pages.push([""]);

  const objects: string[] = [];
  const pageObjectIds: number[] = [];
  const contentObjectIds: number[] = [];

  const catalogId = 1;
  const pagesId = 2;
  const fontId = 3;
  let nextObjectId = 4;

  for (const pageLines of pages) {
    const pageId = nextObjectId++;
    const contentId = nextObjectId++;
    pageObjectIds.push(pageId);
    contentObjectIds.push(contentId);

    const content = [
      "BT",
      "/F1 10 Tf",
      "50 780 Td",
      ...pageLines.map((line, index) => {
        const escaped = simplePdfEncode(line);
        return index === 0 ? `(${escaped}) Tj` : `T* (${escaped}) Tj`;
      }),
      "ET",
    ].join("\n");
    objects[contentId] = `<< /Length ${content.length} >>\nstream\n${content}\nendstream`;

    objects[pageId] = `<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 ${fontId} 0 R >> >> /Contents ${contentId} 0 R >>`;
  }

  objects[pagesId] = `<< /Type /Pages /Kids [${pageObjectIds.map((id) => `${id} 0 R`).join(" ")}] /Count ${pageObjectIds.length} >>`;
  objects[fontId] = `<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>`;
  objects[catalogId] = `<< /Type /Catalog /Pages ${pagesId} 0 R >>`;

  let pdf = "%PDF-1.4\n";
  const offsets: number[] = [0];
  for (let i = 1; i <= objects.length; i++) {
    const object = objects[i];
    if (!object) continue;
    offsets[i] = pdf.length;
    pdf += `${i} 0 obj\n${object}\nendobj\n`;
  }

  const xrefStart = pdf.length;
  pdf += `xref\n0 ${objects.length}\n`;
  pdf += "0000000000 65535 f \n";
  for (let i = 1; i < objects.length; i++) {
    const offset = offsets[i] ?? 0;
    pdf += `${offset.toString().padStart(10, "0")} 00000 n \n`;
  }
  pdf += `trailer\n<< /Size ${objects.length} /Root ${catalogId} 0 R >>\nstartxref\n${xrefStart}\n%%EOF`;
  return new TextEncoder().encode(pdf);
}

async function listLatestDocumentsForProject(client: BackendContext["client"], projectId: string) {
  const docs = await getProjectDocuments(client, projectId);
  const enriched = [];
  for (const doc of docs) {
    const versions = await getDocumentVersions(client, doc.id);
    enriched.push({
      ...doc,
      latest_version: versions[0] ?? null,
      versions,
    });
  }
  return enriched;
}

async function handleGenerateQuestions(ctx: BackendContext, req: Request) {
  const body = await readJsonBody(req);
  const idea = String(body.idea ?? "").trim();
  const specs = String(body.specs ?? "").trim();

  if (idea.length < 10) {
    return jsonResponse(400, { success: false, error: "Idea is required." });
  }

  const result = await callQuestionsAi(idea, specs);
  return jsonResponse(200, {
    success: true,
    ...result,
  });
}

async function handleCreatePaymentOrder(req: Request) {
  const body = await readJsonBody(req);
  const plan = String(body.plan ?? "").trim().toLowerCase();

  if (!isRazorpayPlan(plan)) {
    return jsonResponse(400, { success: false, error: "Plan must be pro, enterprise, or custom." });
  }

  try {
    const order = await createRazorpayOrder(plan);
    return jsonResponse(200, {
      success: true,
      plan,
      ...order,
    });
  } catch (error) {
    return jsonResponse(500, {
      success: false,
      error: error instanceof Error ? error.message : "Failed to create Razorpay order",
    });
  }
}

async function handleGenerateStack(ctx: BackendContext, req: Request) {
  const body = await readJsonBody(req);
  const idea = String(body.idea ?? "").trim();
  const answers = (body.answers && typeof body.answers === "object" ? body.answers : {}) as Record<string, string>;

  if (idea.length < 10) {
    return jsonResponse(400, { success: false, error: "Idea is required." });
  }

  const result = await callStackAi(idea, answers);
  return jsonResponse(200, {
    success: true,
    ...result,
  });
}

async function handleCreateProject(ctx: BackendContext, req: Request) {
  const body = await readJsonBody(req);
  const title = String(body.title ?? "").trim();
  const idea = String(body.idea ?? "").trim();
  const description = body.description ? String(body.description).trim() : undefined;

  const usageCheck = await assertGenerationAllowed(ctx);
  if (!usageCheck.allowed) {
    await logEvent(ctx.client, {
      userId: ctx.user.id,
      route: "/project",
      method: "POST",
      level: "warn",
      message: "Free limit reached",
      statusCode: 429,
      metadata: { code: "LIMIT_EXCEEDED", usage: usageCheck.state },
    });
    return limitExceededResponse(usageCheck.state);
  }

  if (title.length < 2 || title.length > 120) {
    return jsonResponse(400, { success: false, error: "Title must be between 2 and 120 characters." });
  }
  if (idea.length < 20 || idea.length > 4000) {
    return jsonResponse(400, { success: false, error: "Idea must be between 20 and 4000 characters." });
  }

  const project = await createProjectShell(ctx.client, ctx.user.id, title, idea, description);
  const docs = await listLatestDocumentsForProject(ctx.client, project.id);
  const baseOrigin = new URL(req.url).origin;

  await logEvent(ctx.client, {
    userId: ctx.user.id,
    projectId: project.id,
    route: "/project",
    method: "POST",
    message: "Project created",
    metadata: { title },
  });

  return jsonResponse(201, {
    success: true,
    project,
    documents: docs,
    downloadUrl: `${baseOrigin}${ROUTE_PREFIX}/download/${project.id}?scope=project&format=zip`,
  });
}

async function handleCreateSpecHistory(ctx: BackendContext, req: Request) {
  console.log("HISTORY API HIT", { user: ctx.user?.id });
  const body = await readJsonBody(req);
  const projectName = String(body.project_name ?? body.projectName ?? "").trim();
  const ideaInput = String(body.idea_input ?? body.idea ?? "").trim();
  const fileUrl = String(body.file_url ?? body.fileUrl ?? "").trim();

  if (!projectName || !ideaInput || !fileUrl) {
    return jsonResponse(400, { success: false, error: "Missing required fields" });
  }

  try {
    const { error } = await ctx.client.database.from("spec_history").insert([{
      user_id: ctx.user.id,
      project_name: projectName,
      idea_input: ideaInput,
      file_url: fileUrl,
    }]);

    if (error) throw error;

    return jsonResponse(201, { success: true });
  } catch (err) {
    return jsonResponse(500, { success: false, error: err instanceof Error ? err.message : String(err) });
  }
}

async function handleGetUserHistory(ctx: BackendContext, req: Request) {
  try {
    const { data, error } = await ctx.client.database
      .from("spec_history")
      .select("id,project_name,idea_input,file_url,created_at")
      .eq("user_id", ctx.user.id)
      .order("created_at", { ascending: false });

    if (error) throw error;

    return jsonResponse(200, { success: true, history: data });
  } catch (err) {
    return jsonResponse(500, { success: false, error: err instanceof Error ? err.message : String(err) });
  }
}

async function handleFetchProject(ctx: BackendContext, req: Request, projectId: string) {
  if (!isUuid(projectId)) {
    return jsonResponse(400, { success: false, error: "Invalid project id." });
  }

  const project = await getProjectOwnedByUser(ctx.client, projectId, ctx.user.id);
  const docs = await listLatestDocumentsForProject(ctx.client, project.id);
  const baseOrigin = new URL(req.url).origin;

  return jsonResponse(200, {
    success: true,
    project,
    documents: docs.map((doc) => ({
      id: doc.id,
      project_id: doc.project_id,
      document_type: doc.document_type,
      title: doc.title,
      status: doc.status,
      current_version_id: doc.current_version_id,
      latest_checksum: doc.latest_checksum,
      created_at: doc.created_at,
      updated_at: doc.updated_at,
      latest_version: doc.latest_version,
      versions: doc.versions,
      download_urls: {
        markdown: `${baseOrigin}${ROUTE_PREFIX}/download/${doc.id}?scope=document&format=md`,
        pdf: `${baseOrigin}${ROUTE_PREFIX}/download/${doc.id}?scope=document&format=pdf`,
      },
    })),
  });
}

async function handleGenerateDocument(ctx: BackendContext, req: Request, kind: DocKind) {
  const started = Date.now();
  const body = await readJsonBody(req);
  const projectId = String(body.projectId ?? body.project_id ?? "").trim();
  const force = Boolean(body.force ?? false);

  if (!isUuid(projectId)) {
    return jsonResponse(400, { success: false, error: "Valid projectId is required." });
  }

  const project = await getProjectOwnedByUser(ctx.client, projectId, ctx.user.id);
  const doc = await fetchExistingDocument(ctx.client, project.id, kind);
  if (!doc) {
    return jsonResponse(404, { success: false, error: "Document shell was not found for this project." });
  }

  const usageCheck = await assertGenerationAllowed(ctx);
  if (!usageCheck.allowed) {
    await logEvent(ctx.client, {
      userId: ctx.user.id,
      projectId: project.id,
      route: `/generate/${kind}`,
      method: "POST",
      level: "warn",
      message: "Free limit reached",
      statusCode: 429,
      durationMs: Date.now() - started,
      metadata: { document_id: doc.id, code: "LIMIT_EXCEEDED", usage: usageCheck.state },
    });
    return limitExceededResponse(usageCheck.state);
  }

  if (doc.status === "ready" && doc.current_version_id && !force) {
    const versions = await getDocumentVersions(ctx.client, doc.id);
    const latest = versions[0] ?? null;
    return jsonResponse(200, {
      success: true,
      skipped: true,
      reason: "Existing version already available.",
      project,
      document: doc,
      version: latest,
      downloadUrl: latest
        ? `${new URL(req.url).origin}${ROUTE_PREFIX}/download/${doc.id}?scope=document&format=md`
        : null,
    });
  }

  await updateProject(ctx.client, project.id, { generation_state: "generating", current_stage: `generating-${kind}` });
  await updateDocumentStatus(ctx.client, doc.id, { status: "generating" });

  try {

    const existingDocs = await listLatestDocumentsForProject(ctx.client, project.id);
    const summaryDocs = existingDocs.map((item) => ({
      document_type: item.document_type as DocKind,
      title: item.title,
      summary: item.latest_version?.structured_data?.summary ?? item.latest_version?.structured_data?.architecture_overview ?? "",
    }));

    const ai = await callAiForDocument(ctx.client, kind, project, summaryDocs);
    const version = await createDocumentVersion(ctx.client, doc, ai.markdown, ai.structured, AI_MODEL);

    await updateProject(ctx.client, project.id, {
      generation_state: "ready",
      current_stage: `generated-${kind}`,
      last_generated_at: new Date().toISOString(),
      stack_recommendation: kind === "architecture" && ai.structured ? ai.structured : project.stack_recommendation,
    });

    const durationMs = Date.now() - started;
    await logEvent(ctx.client, {
      userId: ctx.user.id,
      projectId: project.id,
      route: `/generate/${kind}`,
      method: "POST",
      message: `${kind} generated successfully`,
      statusCode: 200,
      durationMs,
      metadata: {
        ai_model: AI_MODEL,
        document_id: doc.id,
        version_id: version.id,
      },
    });

    // Increment lifetime_generations after a successful full generation
    try {
      await ctx.client.database.rpc("increment_lifetime_generations", { p_user_id: ctx.user.id, p_units: 1 });
    } catch (incErr) {
      // Log increment failure but do not fail the generation response
      await logEvent(ctx.client, {
        userId: ctx.user.id,
        projectId: project.id,
        route: `/generate/${kind}`,
        method: "POST",
        level: "warn",
        message: "Failed to increment lifetime_generations",
        metadata: { error: incErr instanceof Error ? incErr.message : String(incErr) },
      }).catch(() => {});
    }

    return jsonResponse(200, {
      success: true,
      projectId: project.id,
      document: doc,
      version,
      aiModel: AI_MODEL,
      downloadUrl: `${new URL(req.url).origin}${ROUTE_PREFIX}/download/${doc.id}?scope=document&format=md`,
    });
  } catch (error) {
    await updateProject(ctx.client, project.id, { generation_state: "failed" }).catch(() => {});
    await updateDocumentStatus(ctx.client, doc.id, { status: "failed" }).catch(() => {});

    const usage = await getUsageState(ctx).catch(() => null);
    const isLimitError =
      error instanceof Error &&
      /Daily generation limit exceeded|free limit reached|quota/i.test(error.message);

    await logEvent(ctx.client, {
      userId: ctx.user.id,
      projectId: project.id,
      route: `/generate/${kind}`,
      method: "POST",
      level: "error",
      message: error instanceof Error ? error.message : "Generation failed",
      statusCode: isLimitError ? 429 : 500,
      durationMs: Date.now() - started,
      metadata: { document_id: doc.id, code: isLimitError ? "LIMIT_EXCEEDED" : undefined, usage },
    });
    if (isLimitError && usage) {
      return limitExceededResponse(usage);
    }
    return jsonResponse(500, {
      success: false,
      error: error instanceof Error ? error.message : "Generation failed",
    });
  }
}

async function handleDownload(ctx: BackendContext, req: Request, id: string) {
  const url = new URL(req.url);
  const format = (url.searchParams.get("format") ?? "md") as DownloadFormat;
  const scope = (url.searchParams.get("scope") ?? "document") as "document" | "project";
  const usageCheck = await assertGenerationAllowed(ctx);
  if (!usageCheck.allowed) {
    return limitExceededResponse(usageCheck.state);
  }

  if (!isUuid(id)) {
    return jsonResponse(400, { success: false, error: "Invalid id." });
  }

  if (scope === "project") {
    const project = await getProjectOwnedByUser(ctx.client, id, ctx.user.id);
    const docs = await listLatestDocumentsForProject(ctx.client, project.id);
    const zip = new JSZip();
    zip.file("manifest.json", JSON.stringify({
      project: {
        id: project.id,
        title: project.title,
        idea: project.idea,
        created_at: project.created_at,
      },
      documents: docs.map((doc) => ({
        id: doc.id,
        document_type: doc.document_type,
        title: doc.title,
        latest_version: doc.latest_version?.version_number ?? null,
      })),
    }, null, 2));

    for (const doc of docs) {
      const latest = doc.latest_version;
      if (!latest) continue;
      zip.file(`${doc.document_type}/${slugify(doc.title)}.md`, latest.content_markdown);
      zip.file(`${doc.document_type}/${slugify(doc.title)}.json`, JSON.stringify(latest.structured_data, null, 2));
    }

    const bytes = await zip.generateAsync({ type: "uint8array" });
    return binaryResponse(200, bytes, `${slugify(project.title)}-bundle.zip`, "application/zip");
  }

  const document = await ctx.client.database
    .from("documents")
    .select("*")
    .eq("id", id)
    .eq("user_id", ctx.user.id)
    .maybeSingle();

  if (document.error) {
    return jsonResponse(500, { success: false, error: document.error.message });
  }

  if (!document.data) {
    return jsonResponse(404, { success: false, error: "Document not found." });
  }

  const doc = document.data as DocumentRecord;
  const versions = await getDocumentVersions(ctx.client, doc.id);
  const latest = versions[0];
  if (!latest) {
    return jsonResponse(404, { success: false, error: "No generated version available." });
  }

  const fileBase = slugify(doc.title || titleForKind(doc.document_type));
  if (format === "pdf") {
    const bytes = buildPdfBytes(doc.title, latest.content_markdown);
    return binaryResponse(200, bytes, `${fileBase}.pdf`, "application/pdf");
  }

  return textResponse(200, latest.content_markdown, `${fileBase}.md`, "text/markdown; charset=utf-8");
}

async function handleUsage(ctx: BackendContext) {
  const state = await getUsageState(ctx);
  return jsonResponse(200, {
    success: true,
    ...state,
  });
}

export default async function handler(req: Request): Promise<Response> {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  const route = normalizeRoute(new URL(req.url).pathname);

  if (route === "/health") {
    return jsonResponse(200, { success: true, status: "ok" });
  }

  if (req.method === "POST" && route === "/payments/order") {
    return await handleCreatePaymentOrder(req);
  }

  const context = await getInsForgeContext(req);
  if (context instanceof Response) return context;

  try {
    if (req.method === "GET" && route === "/usage") {
      return await handleUsage(context);
    }

    if (req.method === "POST" && route === "/project") {
      return await handleCreateProject(context, req);
    }

    if (req.method === "POST" && route === "/generate/questions") {
      return await handleGenerateQuestions(context, req);
    }

    if (req.method === "POST" && route === "/generate/stack") {
      return await handleGenerateStack(context, req);
    }

    if (req.method === "GET" && route.startsWith("/project/")) {
      return await handleFetchProject(context, req, route.split("/")[2] ?? "");
    }

    if (req.method === "POST" && route === "/generate/prd") {
      return await handleGenerateDocument(context, req, "prd");
    }

    if (req.method === "POST" && route === "/history") {
      return await handleCreateSpecHistory(context, req);
    }

    if (req.method === "GET" && route === "/history") {
      return await handleGetUserHistory(context, req);
    }

    if (req.method === "POST" && route === "/generate/system-design") {
      return await handleGenerateDocument(context, req, "system_design");
    }

    if (req.method === "POST" && route === "/generate/architecture") {
      return await handleGenerateDocument(context, req, "architecture");
    }

    if (req.method === "GET" && route.startsWith("/download/")) {
      return await handleDownload(context, req, route.split("/")[2] ?? "");
    }

    return jsonResponse(404, {
      success: false,
      error: "Route not found.",
      route,
      supported: [
        "POST /project",
      "POST /generate/questions",
      "POST /generate/stack",
      "POST /payments/order",
      "GET /project/:id",
      "POST /generate/prd",
      "POST /generate/system-design",
        "POST /generate/architecture",
        "GET /download/:id",
      ],
    });
  } catch (error) {
    await logEvent(context.client, {
      userId: context.user.id,
      route,
      method: req.method,
      level: "error",
      message: error instanceof Error ? error.message : "Unhandled backend error",
      statusCode: 500,
      metadata: {
        stack: error instanceof Error ? error.stack : null,
      },
    });
    return jsonResponse(500, {
      success: false,
      error: error instanceof Error ? error.message : "Unhandled backend error",
    });
  }
}
